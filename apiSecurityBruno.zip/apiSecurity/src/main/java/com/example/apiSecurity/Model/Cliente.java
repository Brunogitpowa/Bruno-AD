package com.example.apiSecurity.Model;

import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Getter @Setter
@Table(name="clientes")
public class Cliente {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private int id;
    private String nif;
    private String nombre;
    private String apellidos;
    private String claveseguridad;

}
