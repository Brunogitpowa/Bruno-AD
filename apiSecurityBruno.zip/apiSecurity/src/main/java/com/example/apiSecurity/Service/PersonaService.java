package com.example.apiSecurity.Service;

import com.example.apiSecurity.Model.Persona;
import com.example.apiSecurity.Repository.PersonaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PersonaService {

    private final PersonaRepository personaRepository;

    public void createPersona(Persona persona){
        personaRepository.save(persona);
    }

}
