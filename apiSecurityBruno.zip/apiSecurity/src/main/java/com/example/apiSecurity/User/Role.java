package com.example.apiSecurity.User;

public enum Role {
    ADMIN,
    USER

}
