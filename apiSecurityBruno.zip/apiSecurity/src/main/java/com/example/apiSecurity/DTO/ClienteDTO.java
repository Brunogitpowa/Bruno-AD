package com.example.apiSecurity.DTO;

import com.example.apiSecurity.Model.Cliente;
import lombok.*;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter @Setter
public class ClienteDTO implements Serializable {

    private int id;
    private String nif;
    private String nombre;
    private String apellidos;
    private String claveseguridad;



    public static ClienteDTO convertToDTO(Cliente cliente) {

        ClienteDTO clienteDTO = new ClienteDTO();
        clienteDTO.setId(cliente.getId());
        clienteDTO.setNif(cliente.getNif());
        clienteDTO.setNombre(cliente.getNombre());
        clienteDTO.setApellidos(cliente.getApellidos());

        return clienteDTO;

    }

    public static Cliente convertToEntity(ClienteDTO clienteDTO) {

        Cliente cliente = new Cliente();
        cliente.setId(clienteDTO.getId());
        cliente.setNif(clienteDTO.getNif());
        cliente.setApellidos(cliente.getApellidos());

        return cliente;
    }

}
