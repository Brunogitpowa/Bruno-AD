package com.example.apiSecurity.Controller;

import com.example.apiSecurity.Model.Persona;
import com.example.apiSecurity.Service.PersonaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/persona")
@RequiredArgsConstructor
public class PersonaController {

    private final PersonaService personaService;

    @GetMapping
    public  void createPersona(@RequestBody Persona persona) {

        personaService.createPersona(persona);

    }



    @GetMapping(value= "demo")
    public String welcome(){

        return "Welcome from Security Demo";

    }

}
