package com.example.apiSecurity.Service;

import com.example.apiSecurity.DTO.ClienteDTO;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface ClienteService {

    List<ClienteDTO> getAllClientes();
    ClienteDTO getCliente(int id);
}
