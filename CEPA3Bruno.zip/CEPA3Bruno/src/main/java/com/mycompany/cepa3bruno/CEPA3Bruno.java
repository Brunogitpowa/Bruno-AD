/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cepa3bruno;


import DAO.ActorDAO;
import DAO.DirectorDAO;
import DAO.EstudioDAO;
import DAO.PeliculaDAO;
import Model.Actor;
import Model.Director;
import Model.Estudio;
import Model.Pelicula;
import ORM.HibernateUtil;
import java.util.List;
import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author bruno
 */
public class CEPA3Bruno {
    
    

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        
        
        
        while(true){
            mostrarMenu();
            int opcion = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcion) {
                case 1:
                    menuPelicula();
                    int op = scanner.nextInt();
                    scanner.nextLine();
                    switch (op) {
                        case 1:
                            Pelicula p = new Pelicula();
                            PeliculaDAO pDAO = new PeliculaDAO(sessionFactory);
                            System.out.println("Titulo de la Pelicula: ");
                            String nombre = scanner.nextLine();
                            System.out.println("Año de estreno: ");
                            int anio = scanner.nextInt();
                            scanner.nextLine();
                            System.out.println("Presupuesto de la pelicula: ");
                            int presu = scanner.nextInt();
                            scanner.nextLine();
                            p.setTitulo(nombre);
                            p.setPresupuesto(presu);
                            p.setEstreno(anio);
                            pDAO.insertarPelicula(p);
                            break;
                            
                        case 2:
                            PeliculaDAO pEliminar = new PeliculaDAO(sessionFactory);
                            System.out.println("Id de la Pelicula a eliminar: ");
                            long idEliminar = scanner.nextLong();
                            scanner.nextLine();
                            pEliminar.eliminarPelicula(idEliminar);
                            break;
                            
                        case 3:
                            PeliculaDAO pActualizar = new PeliculaDAO(sessionFactory);
                            System.out.println(pActualizar.obtenerTodasPeliculas());
                            System.out.println("ID de la Pelicula a modificar: ");
                            long idActualizar = scanner.nextLong();
                            scanner.nextLine();
                            System.out.println("Dato a actualizar");
                            System.out.println("1.- Estreno");
                            System.out.println("2.- Presupuesto");
                            System.out.println("3.- Titulo");
                            int datoActualizar = scanner.nextInt();
                            scanner.nextLine();
                            switch (datoActualizar) {
                                case 1:
                                    Pelicula peliEstreno;
                                    System.out.println("Ingresa el año del Estreno: ");
                                    int estreno = scanner.nextInt();
                                    scanner.nextLine();
                                    peliEstreno = pActualizar.obtenerPelicula(idActualizar);
                                    peliEstreno.setEstreno(estreno);
                                    pActualizar.actualizarPelicula(peliEstreno);
                                    break;
                                
                                case 2:
                                    Pelicula peliPresupuesto;
                                    System.out.println("Ingresa el Presupuesto: ");
                                    int presupuesto = scanner.nextInt();
                                    scanner.nextLine();
                                    peliPresupuesto = pActualizar.obtenerPelicula(idActualizar);
                                    peliPresupuesto.setPresupuesto(presupuesto);
                                    pActualizar.actualizarPelicula(peliPresupuesto);
                                    break;
                                
                                case 3:
                                    Pelicula peliTitulo;
                                    System.out.println("Ingresa Titulo: ");
                                    String titulo = scanner.nextLine();
                                    peliTitulo = pActualizar.obtenerPelicula(idActualizar);
                                    peliTitulo.setTitulo(titulo);
                                    pActualizar.actualizarPelicula(peliTitulo);
                                    break;
                                
                                
                            }
                            break;
                            
                        case 4:
                            PeliculaDAO pListaPeliculas = new PeliculaDAO(sessionFactory);
                            List<Pelicula> peliculas = pListaPeliculas.obtenerTodasPeliculas();
                            System.out.println("\nLISTA PELICULAS");
                            for (Pelicula pelicula : peliculas) {
                                System.out.println(pelicula.getTitulo());
                            }
                            break;
                            
                        case 5:
                            break;
                            
                                
                    }       
                    break;
                    
                case 2:
                    menuDirector();
                    int op2 = scanner.nextInt();
                    scanner.nextLine();
                    switch (op2) {
                        case 1:
                            Director d = new Director();
                            DirectorDAO dDAO = new DirectorDAO(sessionFactory);
                            System.out.println("Nombre del Director: ");
                            String nombre = scanner.nextLine();
                            System.out.println("Edad: ");
                            int edad = scanner.nextInt();
                            scanner.nextLine();
                            d.setNombre(nombre);
                            d.setEdad(edad);
                            dDAO.insertarDirector(d);
                            break;
                            
                        case 2:
                            DirectorDAO dEliminar = new DirectorDAO(sessionFactory);
                            System.out.println("Id del Director a eliminar: ");
                            long idEliminar = scanner.nextLong();
                            scanner.nextLine();
                            dEliminar.eliminarDirector(idEliminar);
                            break;
                            
                        case 3:
                            
                            DirectorDAO dActualizar = new DirectorDAO(sessionFactory);
                            System.out.println(dActualizar.obtenerTodosDirectores());
                            System.out.println("ID del Director a modificar: ");
                            long idActualizar = scanner.nextLong();
                            scanner.nextLine();
                            System.out.println("Dato a actualizar");
                            System.out.println("1.- Nombre");
                            System.out.println("2.- Edad");
                            int datoActualizar = scanner.nextInt();
                            scanner.nextLine();
                            switch (datoActualizar) {
                                
                                case 1:
                                    Director directorNombre;
                                    System.out.println("Ingresa el nuevo nombre: ");
                                    String nuevoNombre = scanner.nextLine();
                                    directorNombre = dActualizar.obtenerDirector(idActualizar);
                                    directorNombre.setNombre(nuevoNombre);
                                    dActualizar.actualizarDirector(directorNombre);
                                    break;
                                
                                case 2:
                                    Director directorEdad;
                                    System.out.println("Ingresa la nueva edad: ");
                                    int nuevaEdad = scanner.nextInt();
                                    scanner.nextLine();
                                    directorEdad = dActualizar.obtenerDirector(idActualizar);
                                    directorEdad.setEdad(nuevaEdad);
                                    dActualizar.actualizarDirector(directorEdad);
                                    break;
                                
                                
                            }
                            break;
                            
                        case 4:
                            DirectorDAO dListaDirectores = new DirectorDAO(sessionFactory);
                            List<Director> directores = dListaDirectores.obtenerTodosDirectores();
                            System.out.println("\nLISTA DIRECTORES");
                            for (Director director : directores) {
                                System.out.println(director.getNombre());
                            }
                            break;
                            
                        case 5:
                            break;
                            
                                
                    }       
                    break;
                    
                    
                case 3:
                    menuActor();
                    int op3 = scanner.nextInt();
                    scanner.nextLine();
                    switch (op3) {
                        case 1:
                            
                            Actor a = new Actor();
                            ActorDAO aDAO = new ActorDAO(sessionFactory);
                            System.out.println("Nombre del Actor: ");
                            String nombre = scanner.nextLine();
                            System.out.println("Edad: ");
                            int edad = scanner.nextInt();
                            scanner.nextLine();
                            a.setNombre(nombre);
                            a.setEdad(edad);
                            aDAO.insertarActor(a);
                            break;
                            
                        case 2:
                            ActorDAO aEliminar = new ActorDAO(sessionFactory);
                            System.out.println("Id del actor a eliminar: ");
                            long idEliminar = scanner.nextLong();
                            scanner.nextLine();
                            aEliminar.eliminarActor(idEliminar);
                            break;
                            
                        case 3:
                            ActorDAO aActualizar = new ActorDAO(sessionFactory);
                            System.out.println(aActualizar.obtenerTodosActores());
                            System.out.println("ID del Actor a modificar: ");
                            long idActualizar = scanner.nextLong();
                            scanner.nextLine();
                            System.out.println("Dato a actualizar");
                            System.out.println("1.- Nombre");
                            System.out.println("2.- Edad");
                            int datoActualizar = scanner.nextInt();
                            scanner.nextLine();
                            
                            switch (datoActualizar) {
                                case 1:
                                    
                                    Actor actorNombre;
                                    System.out.println("Ingresa el nuevo nombre: ");
                                    String nuevoNombre = scanner.nextLine();
                                    actorNombre = aActualizar.obtenerActor(idActualizar);
                                    actorNombre.setNombre(nuevoNombre);
                                    aActualizar.actualizarActor(actorNombre);
                                    break;
                                
                                case 2:
                                    
                                    Actor actorEdad;
                                    System.out.println("Ingresa la nueva edad: ");
                                    int nuevaEdad = scanner.nextInt();
                                    scanner.nextLine();
                                    actorEdad = aActualizar.obtenerActor(idActualizar);
                                    actorEdad.setEdad(nuevaEdad);
                                    aActualizar.actualizarActor(actorEdad);
                                    break;
                                
                                
                                
                            }
                            break;
                            
                        case 4:
                            ActorDAO aListaActores = new ActorDAO(sessionFactory);
                            List<Actor> actores = aListaActores.obtenerTodosActores();
                            System.out.println("\nLISTA ACTORES");
                            for (Actor actor : actores) {
                                System.out.println(actor.getNombre());
                            }
                            break;
                            
                        case 5:
                            break;
                            
                                
                    }       
                    break;
                case 4:
                    menuEstudio();
                    int op4 = scanner.nextInt();
                    scanner.nextLine();
                    switch (op4) {
                        case 1:
                            Estudio e = new Estudio();
                            EstudioDAO eDAO = new EstudioDAO(sessionFactory);
                            System.out.println("Nombre del Estudio: ");
                            String nombre = scanner.nextLine();
                            System.out.println("Central: ");
                            String central = scanner.nextLine();
                            e.setNombre(nombre);
                            e.setCentral(central);
                            eDAO.insertarEstudio(e);
                            break;
                            
                        case 2:
                            EstudioDAO eEliminar = new EstudioDAO(sessionFactory);
                            System.out.println("Id del Estudio a eliminar: ");
                            long idEliminar = scanner.nextLong();
                            scanner.nextLine();
                            eEliminar.eliminarEstudio(idEliminar);
                            break;
                            
                        case 3:
                            
                            EstudioDAO eActualizar = new EstudioDAO(sessionFactory);
                            System.out.println(eActualizar.obtenerTodosEstudios());
                            System.out.println("ID del Estudio a modificar: ");
                            long idActualizar = scanner.nextLong();
                            scanner.nextLine();
                            System.out.println("Dato a actualizar");
                            System.out.println("1.- Nombre");
                            System.out.println("2.- Central");
                            int datoActualizar = scanner.nextInt();
                            scanner.nextLine();
                            switch (datoActualizar) {
                                
                                case 1:
                                    Estudio estudioNombre;
                                    System.out.println("Ingresa el nuevo nombre: ");
                                    String nuevoNombre = scanner.nextLine();
                                    estudioNombre = eActualizar.obtenerEstudio(idActualizar);
                                    estudioNombre.setNombre(nuevoNombre);
                                    eActualizar.actualizarEstudio(estudioNombre);
                                    break;
                                
                                case 2:
                                    Estudio estudioCentral;
                                    System.out.println("Ingresa la nueva Central: ");
                                    String nuevaCentral = scanner.nextLine();
                                    estudioCentral = eActualizar.obtenerEstudio(idActualizar);
                                    estudioCentral.setCentral(nuevaCentral);
                                    eActualizar.actualizarEstudio(estudioCentral);
                                    break;
                                
                                
                            }
                            break;
                            
                        case 4:
                            EstudioDAO eListaEstudios = new EstudioDAO(sessionFactory);
                            List<Estudio> estudios = eListaEstudios.obtenerTodosEstudios();
                            System.out.println("\nLISTA ESTUDIOS");
                            for (Estudio estudio : estudios) {
                                System.out.println(estudio.getNombre());
                            }
                            break;
                            
                        case 5:
                            break;
                            
                                
                    }       
                    break;
            }
        }
            
        
        
        
        
    }
    
    public static void mostrarMenu(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("");
        System.out.println("////// MENU //////");
        System.out.println("1.- Pelicula");
        System.out.println("2.- Director");
        System.out.println("3.- Actor");
        System.out.println("4.- Estudio");
        System.out.println("5.- Salir");
        
    }
    
    public static void menuPelicula(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("1.- Insertar pelicula");
        System.out.println("2.- Eliminar pelicula");
        System.out.println("3.- Actualizar pelicula");
        System.out.println("4.- Consultar lista de peliculas");
        System.out.println("5.- Atras");
    }
    
    public static void menuDirector(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("1.- Insertar director");
        System.out.println("2.- Eliminar director");
        System.out.println("3.- Actualizar director");
        System.out.println("4.- Consultar lista de directores");
        System.out.println("5.- Atras");
    }
    
    public static void menuActor(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("1.- Insertar actor");
        System.out.println("2.- Eliminar actor");
        System.out.println("3.- Actualizar actor");
        System.out.println("4.- Consultar lista de actores");
        System.out.println("5.- Atras");
    }
    
    public static void menuEstudio(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("1.- Insertar estudio");
        System.out.println("2.- Eliminar estudio");
        System.out.println("3.- Actualizar estudio");
        System.out.println("4.- Consultar lista de estudios");
        System.out.println("5.- Atras");
    }
     
}
