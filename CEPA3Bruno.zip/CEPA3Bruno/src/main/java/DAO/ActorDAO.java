/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Model.Actor;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author bruno
 */
public class ActorDAO {
    
    private final SessionFactory sessionFactory;
    
    
    
    public ActorDAO(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
    public void insertarActor(Actor actor) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(actor);
            transaction.commit();
        }
    }
    
    
    public void actualizarActor(Actor actor) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.update(actor);
            transaction.commit();
        }
    }
    
    
    public void eliminarActor(Long actorID) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Actor actor = session.get(Actor.class, actorID);
            if (actor != null) {
                session.delete(actor);
            }
            transaction.commit();
        }
    }
    
    
    public Actor obtenerActor(Long actorID) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Actor.class, actorID);
        }
    }
    
    
    public List<Actor> obtenerTodosActores() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM Actor", Actor.class).list();
        }
    }
    
}
