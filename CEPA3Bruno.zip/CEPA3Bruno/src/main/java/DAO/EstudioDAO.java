/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Model.Estudio;
import Model.Pelicula;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author bruno
 */
public class EstudioDAO {
    
    private final SessionFactory sessionFactory;
    
    
    
    public EstudioDAO(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
    public void insertarEstudio(Estudio estudio) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(estudio);
            transaction.commit();
        }
    }
    
    
    public void actualizarEstudio(Estudio estudio) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.update(estudio);
            transaction.commit();
        }
    }
    
    
    public void eliminarEstudio(Long estudioID) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Estudio estudio = session.get(Estudio.class, estudioID);
            if (estudio != null) {
                session.delete(estudio);
            }
            transaction.commit();
        }
    }
    
    
    public Estudio obtenerEstudio(Long estudioID) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Estudio.class, estudioID);
        }
    }
    
    
    public List<Estudio> obtenerTodosEstudios() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM Estudio", Estudio.class).list();
        }
    }
    
}
