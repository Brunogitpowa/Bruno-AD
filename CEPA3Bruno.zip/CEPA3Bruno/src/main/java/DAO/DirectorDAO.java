/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Model.Director;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author bruno
 */
public class DirectorDAO {
    
    private final SessionFactory sessionFactory;
    
    
    
    public DirectorDAO(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
    public void insertarDirector(Director director) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(director);
            transaction.commit();
        }
    }
    
    
    public void actualizarDirector(Director director) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.update(director);
            transaction.commit();
        }
    }
    
    
    public void eliminarDirector(Long directorID) {
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Director director = session.get(Director.class, directorID);
            if (director != null) {
                session.delete(director);
            }
            transaction.commit();
        }
    }
    
    
    public Director obtenerDirector(Long directorID) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Director.class, directorID);
        }
    }
    
    
    public List<Director> obtenerTodosDirectores() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM Director", Director.class).list();
        }
    }
    
}
