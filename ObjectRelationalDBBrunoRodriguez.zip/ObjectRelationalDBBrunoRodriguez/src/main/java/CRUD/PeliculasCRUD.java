package CRUD;

import Utils.ConsoleColors;
import org.postgresql.util.PGobject;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.Scanner;

import static org.example.Main.mostrarMenuCRUD;

public class PeliculasCRUD {

    private static final String url = "jdbc:postgresql://localhost:5432/FILMS";
    private static final String usuario = "postgres";
    private static final String pass = "12345";

    private static final Scanner sc = new Scanner(System.in);

    /*Formulario para rellenar datos de Pelicula nueva*/
    public void insertarPelicula() {
        try (Connection con = DriverManager.getConnection(url, usuario, pass)) {

            System.out.println("Id de la Pelicula: ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.println("Nombre de la pelicula: ");
            String nuevaPelicula = sc.nextLine();
            System.out.println("Sinopsis pelicula: ");
            String sinopsis = sc.nextLine();
            System.out.println("Nombre del protagonista: ");
            String nom = sc.nextLine();
            System.out.println("Edad del protagonista: ");
            int edad = sc.nextInt();
            sc.nextLine();
            System.out.println("Nacionalidad del protagonista: ");
            String nacionalidad = sc.nextLine();
            System.out.println("Numero de peliculas protagonizadas: ");
            int peliculasProtagonizadas = sc.nextInt();
            sc.nextLine();
            System.out.println("Numero de premios del actor: ");
            int numPremios = sc.nextInt();
            sc.nextLine();
            System.out.println("Sueldo de su ultima pelicula: ");
            int sueldo = sc.nextInt();
            sc.nextLine();
            System.out.println("Dureacion en minutos: ");
            int min = sc.nextInt();
            sc.nextLine();
            System.out.println("Año de estreno: ");
            int añoEstreno = sc.nextInt();
            sc.nextLine();
            System.out.println("Nombre del Director: ");
            String nombreDirector = sc.nextLine();
            System.out.println("Edad del director: ");
            int edadDirector = sc.nextInt();
            sc.nextLine();
            System.out.println("Nacionalidad del Director: ");
            String nacionalidadDirector = sc.nextLine();


            /*Esta parte es donde ingresamos los datos de los objetos compuestos*/

            System.out.println("Nombre de la Sala de cine: ");
            String nombreCine = sc.nextLine();
            System.out.println("Ciudad de la Sala: ");
            String ubicacion = sc.nextLine();
            System.out.println("Capacidad del cine: ");
            int capacidad = sc.nextInt();
            sc.nextLine();
            System.out.println("Numero de butacas por sala: ");
            int butacasPorSala = sc.nextInt();
            sc.nextLine();
            System.out.println("Fecha del estreno: ");
            String fechaEstreno = sc.nextLine();
            System.out.println("Butacas libres: ");
            int butacasLibres = sc.nextInt();
            sc.nextLine();
            System.out.println("Butacas vendidas: ");
            int butacasVendidas = sc.nextInt();
            sc.nextLine();

            /*Falta a la consulta proyeccion que es lo que no he  encontrado el error*/
            String into = "insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion) values(?,?,?,?,?,?,?,?,?);";

            try (PreparedStatement statement = con.prepareStatement(into)) {

                PGobject actor = new PGobject();
                actor.setType("datos_actor");
                actor.setValue(String.format("('%s',%d,'%s')", nom, edad, nacionalidad));
                statement.setObject(1, actor);

                PGobject meritos = new PGobject();
                meritos.setType("logro");
                meritos.setValue(String.format("(%d, %d)", peliculasProtagonizadas, numPremios));


                statement.setObject(2, meritos);
                statement.setInt(3, id);
                statement.setInt(4, sueldo);
                statement.setString(5, nuevaPelicula);
                statement.setString(6, sinopsis);
                statement.setInt(7, min);
                statement.setInt(8, añoEstreno);

                PGobject direccion = new PGobject();
                direccion.setType("dirigida");
                direccion.setValue(String.format("(%s, %d, %s)", nombreDirector, edadDirector, nacionalidadDirector));
                statement.setObject(9, direccion);

                /*Aqui tendria que con los "datos ingresados" completar la consulta para introducir todos los datos
                al no introducirlos aparecera null en todos los campos*/

                /*PGobject venta = new PGobject();
                venta.setType("disponibilidad");
                venta.setValue("("+fechaEstreno+","+butacasLibres+","+butacasVendidas+")");

                PGobject asientos = new PGobject();
                asientos.setType("cupo");
                asientos.setValue("("+capacidad+","+butacasPorSala+","+venta.getValue()+")");

                PGobject proyeccion = new PGobject();
                proyeccion.setType("salas");
                proyeccion.setValue("("+nombreCine+","+ ubicacion+","+asientos.getValue());
                statement.setObject(10, proyeccion);*/

                int rowsAffected = statement.executeUpdate();
                System.out.println(rowsAffected + " row(s) inserted.");

            }


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void consultarPelicula(int idpelicula) {
        try (Connection con = DriverManager.getConnection(url, usuario, pass)) {
            String sql = "SELECT * FROM peliculas WHERE id = ?";

            try (PreparedStatement st = con.prepareStatement(sql)) {
                st.setInt(1, idpelicula);
                try (ResultSet rst = st.executeQuery()) {
                    if (rst.next()) {
                        String sinopsis = rst.getString("sinopsis");
                        Object actor = rst.getObject("actor");
                        Object director = rst.getObject("direccion");
                        int duracion = rst.getInt("duracion");
                        int estreno = rst.getInt("año");

                        System.out.println(ConsoleColors.YELLOW + "\t-- " + rst.getString("titulo") + " --" + ConsoleColors.RESET);
                        System.out.println("Sinopsis: " + sinopsis + "\n");
                        System.out.println("Director: " + director + "\n");
                        System.out.println("Protagonista: " + actor + "\n");
                        System.out.println("Duracion y año de estreno: " + duracion + " min, " + estreno);


                        System.out.println("");


                    }
                }

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public void actualizarPelicula(int idPeliculaActualizar, String datoActualizar) {
        System.out.println("Dime el nuevo dato: ");
        String datoNuevo = sc.nextLine();

        try (Connection con = DriverManager.getConnection(url, usuario, pass)) {
            String sql = "UPDATE peliculas SET " + datoActualizar + " = ? WHERE id = ?";
            try (PreparedStatement st = con.prepareStatement(sql)) {
                st.setString(1, datoNuevo);
                st.setInt(2, idPeliculaActualizar);
                int actualizado = st.executeUpdate();
                if (actualizado > 0) {
                    System.out.println("");
                    System.out.println(ConsoleColors.GREEN + "Registroa actualizado con exito" + ConsoleColors.RESET);
                } else {
                    System.out.println("Error en la insercion de datos");

                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void  actualizarObjeto(int idPelicula, String datoActualizar){
        System.out.println("Nombre: ");
        String nuevoNombre = sc.nextLine();
        System.out.println("Edad: ");
        int nuevaEdad = sc.nextInt();
        sc.nextLine();
        System.out.println("Nacionalidad: ");
        String nuevaNacionalidad = sc.nextLine();

        try (Connection con = DriverManager.getConnection(url, usuario, pass)) {
            String sql = "UPDATE peliculas SET " + datoActualizar + " = ? WHERE id = ?";
            try (PreparedStatement st = con.prepareStatement(sql)) {
                if (datoActualizar == "actor") {
                    PGobject actor = new PGobject();
                    actor.setType("datos_actor");
                    actor.setValue(String.format("('%s',%d,'%s')", nuevoNombre, nuevaEdad, nuevaNacionalidad));
                    st.setObject(1, actor);
                    st.setInt(2, idPelicula);
                }else{
                    PGobject director = new PGobject();
                    director.setType("dirigida");
                    director.setValue(String.format("('%s',%d,'%s')", nuevoNombre, nuevaEdad, nuevaNacionalidad));
                    st.setObject(1, director);
                    st.setInt(2, idPelicula);
                }
                int actualizado = st.executeUpdate();
                if (actualizado > 0) {
                    System.out.println("");
                    System.out.println(ConsoleColors.GREEN + "Registro actualizado con exito" + ConsoleColors.RESET);
                } else {
                    System.out.println("Error en la insercion de datos");

                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void actualizarDuracionAño(int idPelicula){
        System.out.println("Añade la duracion: ");
        int nuevaDuracion = sc.nextInt();
        sc.nextLine();
        System.out.println("Nuevo año: ");
        int nuevoAño = sc.nextInt();

        try (Connection con = DriverManager.getConnection(url, usuario, pass)) {
            String sql = "UPDATE peliculas SET duracion=?,año=? WHERE id = ?";
            try (PreparedStatement st = con.prepareStatement(sql)) {
                st.setInt(1, nuevaDuracion);
                st.setInt(2, nuevoAño);
                st.setInt(3, idPelicula);
                int actualizado = st.executeUpdate();
                if (actualizado > 0) {
                    System.out.println("");
                    System.out.println(ConsoleColors.GREEN + "Registro actualizado con exito" + ConsoleColors.RESET);
                } else {
                    System.out.println("Error en la insercion de datos");

                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public void eliminarPelicula(int idPelicula){
        try (Connection con = DriverManager.getConnection(url, usuario, pass)) {
            String sql = "DELETE FROM peliculas WHERE id = ?";
            try (PreparedStatement st = con.prepareStatement(sql)) {
                st.setInt(1, idPelicula);
                int actualizado = st.executeUpdate();
                if (actualizado > 0) {
                    System.out.println("");
                    System.out.println(ConsoleColors.GREEN + "Pelicula borrada con exito" + ConsoleColors.RESET);
                } else {
                    System.out.println("Error al eliminar Pelicula");

                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }


    /*Crea la base de datos tendra que estar conectado a una cualquiera y activo postgresql*/
    public void crearDataBase(String url, String usuario, String pass, String dbName){
        try {

            Class.forName("org.postgresql.Driver");

            Connection conn = DriverManager.getConnection(url, usuario, pass);

            Statement st = conn.createStatement();

            st.execute("CREATE DATABASE "+dbName);

            conn.close();

        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }


    }


    public void ejecutarScript(Connection con, String script){

        Statement st = null;
        try {
            st = con.createStatement();

            /* Aqui ejecutamos el script que encontramos en el directorio src/script.sql */
            String sql = new String(Files.readAllBytes(Paths.get(script)));

            st.execute(sql);
            con.close();

        } catch (SQLException | IOException e) {
            throw new RuntimeException(e);
        }


    }
}