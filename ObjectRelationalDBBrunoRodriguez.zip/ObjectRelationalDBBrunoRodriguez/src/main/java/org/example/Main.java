package org.example;

import CRUD.PeliculasCRUD;
import Utils.ConsoleColors;
import org.postgresql.util.PGobject;

import java.sql.*;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PeliculasCRUD pCRUD = new PeliculasCRUD();


        String url = "jdbc:postgresql://localhost/postgres";
        String usuario = "postgres";
        String pass = "12345";
        String dbName = "brunodb";
        String script = "src/Script.sql";

        /*Creamos la base de datos*/
        pCRUD.crearDataBase(url, usuario, pass, dbName);

        Connection con = null;
        try {

            con = DriverManager.getConnection("jdbc:postgresql://localhost/" + dbName, usuario, pass);
            /*Ejecutamos Script en la base de datos recien creada creada*/
            pCRUD.ejecutarScript(con, script);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        System.out.println("...Base de datos creada con exito");
        System.out.println("...Script ejecutado con exito");
        System.out.println("");
        String nuevaUrl = "jdbc:postgresql://localhost/"+dbName;

        boolean salir = false;

        /*Inicia programa*/
        while (!salir) {
            mostrarMenuCRUD();
            int op = sc.nextInt();
            sc.nextLine();
            switch (op) {
                case 1:
                    try {
                        Class.forName("org.postgresql.Driver");
                        Connection conn = DriverManager.getConnection(nuevaUrl, usuario, pass);
                        String query = "SELECT * FROM peliculas";
                        try (PreparedStatement st = conn.prepareStatement(query)) {
                            try (ResultSet resultSet = st.executeQuery()) {
                                System.out.println(ConsoleColors.CYAN + "Lista de peliculas obtenidas de la Base de datos." + ConsoleColors.RESET);
                                while (resultSet.next()) {
                                    String titulo = resultSet.getString("titulo");
                                    int idPelicula = resultSet.getInt("id");
                                    System.out.println(ConsoleColors.BLUE + idPelicula + "\t" + titulo + ConsoleColors.RESET);

                                }
                                System.out.println("");
                                int detalles = -1;
                                while (detalles != 0) {
                                    System.out.println(ConsoleColors.RED + "/*Introduce <numero> para ver mas detalles o <0> para volver al menu inicial*/" + ConsoleColors.RESET);
                                    detalles = sc.nextInt();
                                    sc.nextLine();
                                    pCRUD.consultarPelicula(detalles);
                                }
                            }
                        }
                    } catch (ClassNotFoundException | SQLException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 2:
                    pCRUD.insertarPelicula();
                    break;

                case 3:
                    mostrarMenuActualizar();
                    int opc = sc.nextInt();
                    sc.nextLine();
                    switch (opc){
                        case 1:
                            String tituloActualizar = "titulo";
                            try {
                                Class.forName("org.postgresql.Driver");
                                Connection conn = DriverManager.getConnection(nuevaUrl, usuario, pass);
                                String query = "SELECT * FROM peliculas";
                                try (PreparedStatement st = conn.prepareStatement(query)) {
                                    try (ResultSet resultSet = st.executeQuery()) {
                                        System.out.println("Lista de peliculas");
                                        while (resultSet.next()) {
                                            String titulo = resultSet.getString("titulo");
                                            int idPelicula = resultSet.getInt("id");
                                            System.out.println(idPelicula + "\t" + titulo);

                                        }
                                        System.out.println("");
                                        int idPeliModificar = -1;
                                        while (idPeliModificar != 0) {
                                            System.out.println(ConsoleColors.RED + "Pulsa <numero> para modificar titulo o <0> para salir" + ConsoleColors.RESET);
                                            idPeliModificar = sc.nextInt();
                                            if (idPeliModificar != 0) {
                                                sc.nextLine();
                                                pCRUD.actualizarPelicula(idPeliModificar, tituloActualizar);
                                            } else {
                                                System.out.println("Volviendo al menu principal...");
                                            }
                                        }
                                    }
                                }
                            } catch (ClassNotFoundException | SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;

                        case 2:
                            String sinopsisActualizar = "sinopsis";
                            try {
                                Class.forName("org.postgresql.Driver");
                                Connection conn = DriverManager.getConnection(nuevaUrl, usuario, pass);
                                String query = "SELECT * FROM peliculas";
                                try (PreparedStatement st = conn.prepareStatement(query)) {
                                    try (ResultSet resultSet = st.executeQuery()) {
                                        System.out.println("Lista de peliculas");
                                        while (resultSet.next()) {
                                            String titulo = resultSet.getString("titulo");
                                            int idPelicula = resultSet.getInt("id");
                                            System.out.println(idPelicula + "\t" + titulo);

                                        }
                                        System.out.println("");
                                        int idPeliModificar = -1;
                                        while (idPeliModificar != 0) {
                                            System.out.println(ConsoleColors.RED + "Pulsa <numero> para modificar la sinopsis o <0> para salir" + ConsoleColors.RESET);
                                            idPeliModificar = sc.nextInt();
                                            if (idPeliModificar != 0) {
                                                sc.nextLine();
                                                pCRUD.actualizarPelicula(idPeliModificar, sinopsisActualizar);
                                            } else {
                                                System.out.println("Volviendo al menu principal...");
                                            }
                                        }
                                    }
                                }
                            } catch (ClassNotFoundException | SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;

                        case 3:
                            String actorActualizar = "actor";
                            try {
                                Class.forName("org.postgresql.Driver");
                                Connection conn = DriverManager.getConnection(nuevaUrl, usuario, pass);
                                String query = "SELECT * FROM peliculas";
                                try (PreparedStatement st = conn.prepareStatement(query)) {
                                    try (ResultSet resultSet = st.executeQuery()) {
                                        System.out.println("Lista de peliculas");
                                        while (resultSet.next()) {
                                            String titulo = resultSet.getString("titulo");
                                            int idPelicula = resultSet.getInt("id");
                                            PGobject actor = (PGobject) resultSet.getObject("actor");
                                            System.out.println(idPelicula + "\t" + titulo + "\nActor: " + actor +"\n");

                                        }
                                        System.out.println("");
                                        int idPeliModificar = -1;
                                        while (idPeliModificar != 0) {
                                            System.out.println(ConsoleColors.RED + "Pulsa <numero> para modificar el actor o <0> para salir" + ConsoleColors.RESET);
                                            idPeliModificar = sc.nextInt();
                                            if (idPeliModificar != 0) {
                                                sc.nextLine();
                                                pCRUD.actualizarObjeto(idPeliModificar, actorActualizar);
                                            } else {
                                                System.out.println("Volviendo al menu principal...");
                                            }
                                        }
                                    }
                                }
                            } catch (ClassNotFoundException | SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;

                        case 4:
                            String directorActualizar = "direccion";
                            try {
                                Class.forName("org.postgresql.Driver");
                                Connection conn = DriverManager.getConnection(nuevaUrl, usuario, pass);
                                String query = "SELECT * FROM peliculas";
                                try (PreparedStatement st = conn.prepareStatement(query)) {
                                    try (ResultSet resultSet = st.executeQuery()) {
                                        System.out.println("Lista de peliculas");
                                        while (resultSet.next()) {
                                            String titulo = resultSet.getString("titulo");
                                            int idPelicula = resultSet.getInt("id");
                                            PGobject direccion = (PGobject) resultSet.getObject("direccion");
                                            System.out.println(idPelicula + "\t" + titulo + "\nDirector: " + direccion +"\n" );

                                        }
                                        System.out.println("");
                                        int idPeliModificar = -1;
                                        while (idPeliModificar != 0) {
                                            System.out.println(ConsoleColors.RED + "Pulsa <numero> para modificar el actor o <0> para salir" + ConsoleColors.RESET);
                                            idPeliModificar = sc.nextInt();
                                            if (idPeliModificar != 0) {
                                                sc.nextLine();
                                                pCRUD.actualizarObjeto(idPeliModificar, directorActualizar);
                                            } else {
                                                System.out.println("Volviendo al menu principal...");
                                            }
                                        }
                                    }
                                }
                            } catch (ClassNotFoundException | SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;

                        case 5:
                            String duracionActualizar = "duracion" ;
                            String estrenoActualizar = "año";
                            try {
                                Class.forName("org.postgresql.Driver");
                                Connection conn = DriverManager.getConnection(nuevaUrl, usuario, pass);
                                String query = "SELECT * FROM peliculas";
                                try (PreparedStatement st = conn.prepareStatement(query)) {
                                    try (ResultSet resultSet = st.executeQuery()) {
                                        System.out.println("Lista de peliculas");
                                        while (resultSet.next()) {
                                            String titulo = resultSet.getString("titulo");
                                            int idPelicula = resultSet.getInt("id");
                                            int duracion = resultSet.getInt("duracion");
                                            int estreno = resultSet.getInt("año");
                                            System.out.println(idPelicula + "\t" + titulo + "\nDuracion: " + duracion +" min\nEstreno: " + estreno + "\n");

                                        }
                                        System.out.println("");
                                        int idPeliModificar = -1;
                                        while (idPeliModificar != 0) {
                                            System.out.println(ConsoleColors.RED + "Pulsa <numero> para modificar la Duracion y estreno o <0> para salir" + ConsoleColors.RESET);
                                            idPeliModificar = sc.nextInt();
                                            if (idPeliModificar != 0) {
                                                sc.nextLine();
                                                pCRUD.actualizarDuracionAño(idPeliModificar);
                                            } else {
                                                System.out.println("Volviendo al menu principal...");
                                            }
                                        }
                                    }
                                }
                            } catch (ClassNotFoundException | SQLException e) {
                                System.out.println(e.getMessage());
                            }
                            break;

                        case 6:
                            break;
                    }
                case 4:
                    try {
                        Class.forName("org.postgresql.Driver");
                        Connection conn = DriverManager.getConnection(nuevaUrl, usuario, pass);
                        String query = "SELECT * FROM peliculas";
                        try (PreparedStatement st = conn.prepareStatement(query)) {
                            try (ResultSet resultSet = st.executeQuery()) {
                                System.out.println("Lista de peliculas");
                                while (resultSet.next()) {
                                    String titulo = resultSet.getString("titulo");
                                    int idPelicula = resultSet.getInt("id");
                                    System.out.println(idPelicula + "\t" + titulo);

                                }
                                System.out.println("");
                                int idPeliModificar = -1;
                                while (idPeliModificar != 0) {
                                    /*Submenu una vez vemos la lista para seleccionar la pelicula que sobre la que queremos trabajar*/
                                    System.out.println(ConsoleColors.RED + "Introduce <numero> para borrar pelicula o <0> para salir" + ConsoleColors.RESET);
                                    idPeliModificar = sc.nextInt();
                                    if (idPeliModificar != 0) {
                                        sc.nextLine();
                                        pCRUD.eliminarPelicula(idPeliModificar);
                                    } else {
                                        System.out.println("Volviendo al menu principal...");
                                    }
                                }
                            }
                        }
                    } catch (ClassNotFoundException | SQLException e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 5:
                    System.out.println("¡¡ Hasta pronto !!");
                    salir = true;
                    break;
            }
        }
    }
    /*Menu principal*/
    public static void mostrarMenuCRUD(){
        System.out.println("");
        System.out.println("////// MENU CRUD //////");
        System.out.println("1.- Consultar pelicula");
        System.out.println("2.- Insertar pelicula");
        System.out.println("3.- Actualizar registro pelicula");
        System.out.println("4.- Borrar pelicula");
        System.out.println("5.- Salir");
    }
    /*Menu para actualizar datos de manera individual*/
    public static void mostrarMenuActualizar(){
        System.out.println("-- Actualizar --");
        System.out.println("1.-Titulo");
        System.out.println("2.-Sinopsis");
        System.out.println("3.-Actor");
        System.out.println("4.-Director");
        System.out.println("5.-Duracion y Año de Estreno");
        System.out.println("6.-Volver a menu principal");
    }

}
