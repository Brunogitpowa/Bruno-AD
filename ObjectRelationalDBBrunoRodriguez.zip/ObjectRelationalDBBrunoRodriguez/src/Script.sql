create type logro as(
	numero_peliculas INT,
	premios INT
);

create type disponibilidad as(
	fecha_hora TIMESTAMP,
	asientos_disponibles INT,
	asientos_vendidos INT
);


create type cupo as(
	capacidad INT,
	numero_asientos INT,
	venta disponibilidad
);

create type salas as(
	nombre VARCHAR(100),
	ubicacion VARCHAR(100),
	asientos cupo
);

create type datos_actor as(
	nombre VARCHAR(100),
	edad INT,
	nacionalidad VARCHAR(50)
);

create type dirigida as(
	nombre VARCHAR(100),
	edad INT,
	nacionalidad VARCHAR(50)
);

CREATE TABLE actores (
    id SERIAL PRIMARY KEY,
    actor datos_actor,
    meritos logro,
    pelicula_id INT 
);

create table directores(
	director datos_actor,
	pelicula_id INT,
	meritos logro
);

create table protagonista(
	sueldo INT
) inherits (actores);

CREATE TABLE peliculas (
    id SERIAL PRIMARY KEY,
    titulo VARCHAR(100),
    sinopsis TEXT,
    duracion INT,
    año INT,
    direccion dirigida,
    proyeccion salas
) inherits (protagonista);



insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion,proyeccion) values(('Michael J. Fox',62,'Canadiense'),(16,12),2,5000000,'Regreso al futuro','Relata las aventuras de Marty McFly,
un adolescente rebelde que vive con sus padres y viaja al pasado desde 1985, su epoca, a 1955, la epoca en que sus padres se conocieron. Finalmente
cambia los hechos especificos de la linea original del tiempo en que sus padres se conocieron y se enamoraron. Debido a esto, Marty debe recurrir a la ayuda
del Dr. Emmett Brown para reunir a sus padres de nuevo.',117,1985,('Robert Zemeckis',71,'Estadounidense'),
('CINES PASCUAL','Madrid',(700,70,('1985-07-04 16:00:00',0,70))));

insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion,proyeccion) values(('Nicolas Cage',59,'Estadounidense'),(51,3),3,12000000,'La busqueda','Benjamin Franklin Gates (Nicolas Cage) 
ha dedicado su vida a buscar el legendario tesoro de los Caballeros Templarios, del que se decía que estaba escondido en algún lugar de Estados Unidos. 
Durante siete generaciones, la familia Gates, siguiendo las pistas que dejaron los "Padres Fundadores" de Estados Unidos, recorrieron el país en busca del tesoro. 
Cuando, por fin, Ben descubre la pista definitiva: un mapa oculto en el reverso de la Declaración de Independencia, la noticia llega a oídos de su rival Ian Howe (Sean Bean). 
Para impedir que el documento caiga en manos de alguien tan peligroso, Gates cuenta con la ayuda de su compañero de aventuras Riley (Justin Bartha), un genio de la tecnología, 
y de Abigail Chase (Diane Kruger), la atractiva conservadora de los Archivos Nacionales.',131,2004,('Jon Turteltaub',61,'Estadounidense'),
('CINES VICTORIA','Barcelona',(1200,120,('2004-07-15 16:00:00',8,112))));

insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion,proyeccion) values(('Henry Thomas',52,'Estadounidense'),(12,1),4,null,'E.T., el extraterrestre','Un pequeño extraterrestre de otro planeta 
queda abandonado en la Tierra cuando su nave se olvida de él. Está completamente solo y asustado hasta que Elliott, un niño de nueve años, lo encuentra y decide 
esconderlo en su casa para protegerlo. El chico y sus hermanos intentarán encontrar la forma de devolver al extraterrestre a su planeta antes de que lo encuentren 
los científicos y la policía.',114,1982,('Steven Spielberg',76,'Estadounidense'),
('CINES PASCUAL','Madrid',(700,70,('1982-06-11 16:00:00',0,70))));

insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion,proyeccion) values(('Mark Richard Hamill',72,'Estadounidense'),(25,2),5,null,'Star wars','La trama describe la historia de un grupo de 
guerrilleros conocidos como la Alianza Rebelde cuyo objetivo es destruir la estación espacial Estrella de la Muerte, creada por el opresor Imperio Galáctico. 
Desde una perspectiva general, la historia se enfoca en un joven granjero llamado Luke Skywalker, quien, de forma repentina, se convertirá en un héroe 
conforme acompaña al Maestro Jedi Obi-Wan Kenobi en una misión que lo llevará a unirse a la Alianza Rebelde para ayudarles a destruir 
la estación espacial del Imperio. ',121,1977,('George Lucas',79,'Estadounidense'),
 ('CINES VICTORIA','Barcelona',(1200,120,('1977-11-07 16:00:00',0,120))));

insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion,proyeccion) values(('Elijah Wood',42,'Estadounidense'),(10,3),1,null,'Harry Potter y la piedra filosofal', 'El día en que cumple once años, 
Harry Potter descubre que es hijo de dos conocidos hechiceros, de los que ha heredado poderes mágicos. 
Deberá acudir entonces a una famosa escuela de magia y hechicería: Howards.',117,1985,('Chris Columbus',65,'Estadounidense'),
('CINES PASCUAL','Madrid',(700,70,('1985-07-04 16:00:00',23,47))));

insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion,proyeccion) values(('Russell Crowe',59,'Neozelandes'),(51,7),7,7000000,'Gladiator','Crowe interpreta a Máximo Décimo Meridio, un leal 
general hispano del ejército del Imperio romano que es traicionado por Cómodo, el ambicioso hijo del emperador Marco Aurelio, quien ha asesinado a su padre 
y se ha hecho con el trono. Forzado a convertirse en esclavo, Máximo triunfa como gladiador mientras anhela vengar la muerte de su familia y la del emperador. '
,155,2000,('Ridley Scott',85,'Britanico'),
('CINES TALCUAL','Valencia',(150,100,('1985-07-04 16:00:00',0,100))));

insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion,proyeccion) values(('Sam Worthington',47,'Australiano'),(36,null),8,65000000,'Avatar','Entramos en el mundo Avatar 
de la mano de Jake Sully, un ex-Marine en silla de ruedas, que ha sido reclutado para viajar a Pandora, donde existe un mineral raro y muy preciado 
que puede solucionar la crisis energética existente en la Tierra.',162,2009,('James Cameron',69,'Canadiense'),
('CINES VICTORIA','Barcelona',(1200,120,('2009-03-12 16:00:00',7,113))));

insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion,proyeccion) values(('Chritian Bale',49,'Britanica'),(49,9),9,30000000,'The dark night','Con la ayuda del teniente Jim Gordon 
y del Fiscal del Distrito Harvey Dent, Batman mantiene a raya el crimen organizado en Gotham. Todo cambia cuando aparece el Joker, un nuevo criminal 
que desencadena el caos y tiene aterrados a los ciudadanos.',152,2008,('Christopher Nolan',53,'Britanico'),
('CINES VICTORIA','Barcelona',(1200,120,('2008-12-10 16:00:00',12,108))));

insert into peliculas(actor,meritos,pelicula_id,sueldo,titulo,sinopsis,duracion,año,direccion,proyeccion) values(('Matthew McConaughey',54,'Estadounidense'),(50,8),10,null,'Interstellar','Un grupo de científicos y exploradores, 
encabezados por Cooper, se embarcan en un viaje espacial para encontrar un lugar con las condiciones necesarias para reemplazar a la Tierra y comenzar 
una nueva vida allí. La Tierra está llegando a su fin y este grupo necesita encontrar un planeta más allá de nuestra galaxia que garantice el futuro 
de la raza humana.',169,2014,('Christopher Nolan',53,'Britanico'),
('CINES PASCUAL','Madrid',(700,70,('2014-9-10 16:00:00',0,70))));








