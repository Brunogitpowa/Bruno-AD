package com.example.webSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
