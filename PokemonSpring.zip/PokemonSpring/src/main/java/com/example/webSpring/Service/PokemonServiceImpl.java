package com.example.webSpring.Service;

import com.example.webSpring.DTO.PokemonDTO;
import com.example.webSpring.Model.Pokemon;
import com.example.webSpring.Repository.PokemonRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

import static com.example.webSpring.DTO.PokemonDTO.convertoToDTO;

@Service
public class PokemonServiceImpl implements PokemonService {

    @Autowired
    private PokemonRepository pokemonRepository;

    public List<PokemonDTO> getAllPokemon(){
        return pokemonRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    public PokemonDTO getPokemon(int id){
        Pokemon pokemon = pokemonRepository.findById(id)
                .orElseThrow(()-> new EntityNotFoundException("Pokemon con id " + id + " no encontrado"));
        return convertoToDTO(pokemon);

    }

    private PokemonDTO convertToDto(Pokemon pokemon) {
        PokemonDTO pokemonDTO = new PokemonDTO();
        pokemonDTO.setId(pokemon.getId());
        pokemonDTO.setNombre(pokemon.getNombre());
        pokemonDTO.setHp(pokemon.getHp());
        pokemonDTO.setAtaque(pokemon.getAtaque());
        pokemonDTO.setDefensa(pokemon.getDefensa());
        pokemonDTO.setVelocidad(pokemon.getVelocidad());
        pokemonDTO.setAtaqueEspecial(pokemon.getAtaqueEspecial());
        pokemonDTO.setDefensaEspecial(pokemon.getDefensaEspecial());
        pokemonDTO.setFoto(pokemon.getFoto());
        return pokemonDTO;
    }

}
