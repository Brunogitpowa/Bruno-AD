package com.example.webSpring.Controller;

import com.example.webSpring.DTO.PokemonDTO;
import com.example.webSpring.Model.Pokemon;
import com.example.webSpring.Service.PokemonService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/lista")
public class listaPokemonController {

    private final PokemonService pokemonService;

    public listaPokemonController(PokemonService pokemonService) {
        this.pokemonService = pokemonService;
    }

    /*@GetMapping("/all/images")
    public String getAllPokemon(Model model) {
        List<PokemonDTO> pokemonList = pokemonService.getAllPokemon();
        List<String> imagePaths = pokemonList.stream()
                .map(PokemonDTO::getFoto)
                .collect(Collectors.toList());
        model.addAttribute("imagePaths", imagePaths);
        return "listaPokemon";
    }*/
    @GetMapping("/images")
    public String mostrarListaPokemon(Model model) {
        // Obtén la información necesaria de tus Pokémon, incluyendo IDs e imágenes
        List<PokemonDTO> pokemonInfoList = pokemonService.getAllPokemon();

        // Extraer las rutas de las imágenes y los IDs de la lista de PokemonDTO
        List<String> imagePaths = pokemonInfoList.stream()
                .map(PokemonDTO::getFoto)
                .collect(Collectors.toList());

        List<Integer> pokemonIds = pokemonInfoList.stream()
                .map(PokemonDTO::getId)
                .collect(Collectors.toList());

        // Pasa las listas al modelo para que se pueda acceder desde Thymeleaf
        model.addAttribute("imagePaths", imagePaths);
        model.addAttribute("id", pokemonIds);

        // Retorna el nombre de la vista Thymeleaf que mostrará la lista de Pokémon
        return "listaPokemon";
    }
}