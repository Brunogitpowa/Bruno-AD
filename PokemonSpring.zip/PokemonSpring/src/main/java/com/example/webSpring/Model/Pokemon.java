package com.example.webSpring.Model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;
import lombok.Getter;
import lombok.Setter;

@Entity
@Data
@Getter @Setter
@Table(name="pokemon")
public class Pokemon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nombre;
    private int hp;
    private int ataque;
    private int defensa;
    private int velocidad;

    @Column(name="ataque_especial")
    private int ataqueEspecial;
    @Column(name="defensa_especial")
    private int defensaEspecial;
    @Column(name="imagen_path")
    private String foto;


}
