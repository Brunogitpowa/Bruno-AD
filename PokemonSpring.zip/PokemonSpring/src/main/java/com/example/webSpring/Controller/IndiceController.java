package com.example.webSpring.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndiceController {

    @GetMapping("/")
    public String mostrarIndice() {
        return "indice";
    }
}
