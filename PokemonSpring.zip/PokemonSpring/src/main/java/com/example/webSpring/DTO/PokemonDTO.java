package com.example.webSpring.DTO;

import com.example.webSpring.Model.Pokemon;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter @Setter
public class PokemonDTO implements Serializable {

    private int id;
    private String nombre;
    private int hp;
    private int ataque;
    private int defensa;
    private int velocidad;
    private int ataqueEspecial;
    private int defensaEspecial;
    private String foto;


    public static PokemonDTO convertoToDTO(Pokemon pokemon){
        PokemonDTO pokemonDTO = new PokemonDTO();
        pokemonDTO.setId(pokemon.getId());
        pokemonDTO.setNombre(pokemon.getNombre());
        pokemonDTO.setHp(pokemon.getHp());
        pokemonDTO.setAtaque(pokemon.getAtaque());
        pokemonDTO.setDefensa(pokemon.getDefensa());
        pokemonDTO.setVelocidad(pokemon.getVelocidad());
        pokemonDTO.setAtaqueEspecial(pokemon.getAtaqueEspecial());
        pokemonDTO.setDefensaEspecial(pokemon.getDefensaEspecial());
        pokemonDTO.setFoto(pokemon.getFoto());

        return pokemonDTO;
    }

    public static Pokemon convertToEntity(PokemonDTO pokemonDTO){
        Pokemon pokemon = new Pokemon();
        pokemon.setId(pokemonDTO.getId());
        pokemon.setNombre(pokemonDTO.getNombre());
        pokemon.setHp(pokemonDTO.getHp());
        pokemon.setAtaque(pokemonDTO.getAtaque());
        pokemon.setDefensa(pokemonDTO.getDefensa());
        pokemon.setVelocidad(pokemonDTO.getVelocidad());
        pokemon.setAtaqueEspecial(pokemonDTO.getAtaqueEspecial());
        pokemon.setDefensaEspecial(pokemonDTO.getDefensaEspecial());
        pokemon.setFoto(pokemonDTO.getFoto());

        return pokemon;
    }



}

