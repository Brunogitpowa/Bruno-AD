package com.example.webSpring.Service;

import com.example.webSpring.DTO.PokemonDTO;

import java.util.List;

public interface PokemonService {

    List<PokemonDTO> getAllPokemon();
    PokemonDTO getPokemon(int id);
}
