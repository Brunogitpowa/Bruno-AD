package com.example.webSpring.Controller;

import com.example.webSpring.DTO.PokemonDTO;
import com.example.webSpring.Model.Pokemon;
import com.example.webSpring.Repository.PokemonRepository;
import com.example.webSpring.Service.PokemonServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/pokemon")
public class PokemonController {
    @Autowired
    private PokemonServiceImpl pokemonService;

    //@GetMapping("/pokemon")
    //public String crud(){
    //    return "listaPokemon.html";
    //}

    @GetMapping("/all")
    public List<PokemonDTO> getAllPokemon(){
        return pokemonService.getAllPokemon();
    }


    @GetMapping("/{id}")
    public String mostrarDetallesPokemon(@PathVariable int id, Model model) {
        // Aquí debes obtener los detalles del Pokemon con el ID proporcionado y pasarlos al modelo
        // Puedes realizar la lógica para obtener los detalles del Pokemon desde tu servicio o repositorio

        // Supongamos que tienes un servicio llamado pokemonService para obtener detalles del Pokemon
        PokemonDTO pokemon = pokemonService.getPokemon(id);

        // Agregar el Pokemon al modelo
        model.addAttribute("pokemon", pokemon);
        System.out.println(model.asMap());

        return "detallesPokemon";
    }

    /*@GetMapping("/{id}")
    public PokemonDTO getPokemon(@PathVariable int id){
        return pokemonService.getPokemon(id);
    }*/

}
